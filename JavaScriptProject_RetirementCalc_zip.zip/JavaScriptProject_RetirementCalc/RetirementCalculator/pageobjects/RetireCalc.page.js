const Page = require('./page');
const RetirementCalc = require('../testData/RetirmentCalc.json');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class RetireCalc extends Page {
    /**
     * define selectors using getter methods
     */
    get retireCalcPageLoad () {
        return $('#dsgint-nav-menu-item-1.1');
    }
    get pageTitlePageLoad () {
        return $('#calculator-intro-section');
    }
    get currentAge () {
        return $('#current-age');
    }
    get retirementAge () {
        return $('#retirement-age');
    }
    get currentAnnualIncome () {
        return $('#current-income');
    }
    get spouseAnnualIncome () {
        return $('#spouse-income');
    }
    get currentTotalSaving () {
        return $('#current-total-savings');
    }
    get currentRetireContrib () {
        return $('#current-annual-savings');
    }
    get annualRetirementContributionIncrease () {
        return $('//input[@id= "savings-increase-rate"]');
    }
    get ssnInputYes () {
        return $('//label[@for= "yes-social-benefits"]');
    }
    get ssnInputNo () {
        return $('//label[@for= "no-social-benefits"]');
    }
    get marriedCheck () {
        return $('//label[@for= "married"]');
    }
    get singleCheck () {
        return $('//label[@for= "single"]');
    }
    get ssnOverrideAmt () {
        return $('//input[@id= "social-security-override"]');
    }
    get getDefaultValue () {
        return $('//a[contains(text(),"Adjust default values")]');
    }
    get additionAmt () {
        return $('//input[@id= "additional-income"]');
    }
    get yearsofRetirementNeedsLast () {
        return $('//input[@id= "retirement-duration"]');
    }
    get postRetireYes () {
        return $('//label[@for= "include-inflation"]');
    }
    get postRetireNo () {
        return $('//label[@for= "exclude-inflation"]');
    }
    get expectedInflationRate () {
        return $('//input[@id= "expected-inflation-rate"]');
    }
    get percenFinalAnnualIncomeDesired () {
        return $('//input[@id= "retirement-annual-income"]');
    }
    get preRetireInvestmentReturn () {
        return $('//input[@id= "pre-retirement-roi"]');
    }
    get postRetirInveReturn () {
        return $('//input[@id= "post-retirement-roi"]');
    }
    get saveChangesButton () {
        return $('//button[contains(text(),"Save changes")]');
    }
    get submitButton () {
        return $('//button[@data-tag-id="submit"]');
    }
    get resultText () {
        return $('//div[@id="calculator-results-container"]/h3');
    }
    get reportContent () {
        return $('//div[@id="calculator-results-container"]//p');
    }
    get socialSecurityAsText () {
        return $('//label[@for="social-security-override"]');
    }
    get maritalStatusAsText () {
        return $('//legend[@id="marital-status-label"]');
    }

    async enterCurrentAge (age) {
        try {
            await browser.pause(2000);
            await browser.keys('Enter')
            // Check Current Age
            if (age>0) {
                 console.log("Valid Current Age :!"+age);
                 await this.pageTitlePageLoad.click();
                 await browser.pause(3000);
                //  await this.currentAge.click();
                 await this.currentAge.setValue(age);
                 await browser.pause(1000);
             }
             else{
                 throw("Invalid Current Age : "+age)
             } 
             var text = await this.currentAge.getValue();
             expect(parseFloat(text)).toEqual(parseFloat(age))
             console.log("Valid Current Age!"+age);
            // return await this.currentAge.getValue();
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }

    async enterRetirementAge (age) {
        try{
            await browser.pause(200);
            // Check Retirement Age
            if (age>0) {
                console.log("Valid Retirement Age!");
                await this.retirementAge.click();
                await this.retirementAge.setValue(age);
            }else{
                console.log("Invalid Retirement Age : "+age);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
     }

    async enterCurrentAnnualIncome (income) {
        try {
            await browser.pause(200);
            if (income > 0) {
                console.log("Current Income should be greater than 0!");
                await this.currentAnnualIncome.click();
                await this.currentAnnualIncome.setValue(income); 
            } else {
                console.log("Invalid Current Income : "+income);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }

    async enterSpouseAnnualIncome (income) {
        try{
            await browser.pause(200);
            // Check Spouse Income
            if (income > 0) {
                console.log("Spouse Income should be greater than 0!");
                await this.spouseAnnualIncome.click();
                await this.spouseAnnualIncome.setValue(income);
            } else {
                console.log("Invalid Spouse Income : "+income);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterCurrentRetirementSavings (saving) {
        try{
            await browser.pause(200);
            // Check Current Retirement Saving
            if (saving > 0) {
                console.log("Current Retirement Saving should be greater than 0!");
                await this.currentTotalSaving.click();
                await this.currentTotalSaving.setValue(saving);
            } else {
                console.log("Invalid Current Retirement Saving : "+saving);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterCurrentRetirementContribution (saving) {
        try {
            await browser.pause(200);
            // Check Current Retirement Contribution
            if (saving > 0) {
                console.log("Current Retirement Contribution should be greater than 0!");
                await this.currentRetireContrib.click();
                await this.currentRetireContrib.setValue(saving);
            } else {
                console.log("Invalid Current Retirement Contribution : "+saving);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterAnnualRetirementContributionIncrease (saving) {
        try {
            await browser.pause(500);
            // Check Rate of increase in your savings each year
            if (saving > 0) {
                console.log("Rate of increase in your savings each year should be greater than 0!");
                await this.annualRetirementContributionIncrease.click();
                await this.annualRetirementContributionIncrease.setValue(saving);
              }  else {
                    console.log("Invalid Rate of increase in your savings each year : "+saving);
                }   
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
        
    }
    async enterSocialSecurityIncome (ssn) {
        try {
            await browser.pause(200);
            ssn = ssn.toLowerCase();
            // Check Social Security benifits
            if (ssn.includes("y")) {
                 console.log("Social Security benifits is selected as Yes!");
                 await this.ssnInputYes.click();
             }
             else if (ssn.includes("n")) {
                console.log("Social Security benifits is not selected as No!");
                await this.ssnInputNo.click();
            }else {
                 throw("Invalid input for Social Security benifit : "+ ssn);
             } 
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterRelationshipStatus (status) {
        try {
            await browser.pause(200);
            status = status.toLowerCase();
            // Check Relationship Status
            if (status.includes("s")) {
                 console.log("Relationship Status is Single!");
                 await this.singleCheck.click();
             }
             else if (status.includes("m")) {
                console.log("Relationship Status is Married!");
                await this.marriedCheck.click();
            }else {
                 throw("Invalid input for Relationship Status : "+ ssn);
             } 
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterSocialSecurityOverride (override) {
        try {
            await browser.pause(200);
            // Check Social Security Override Amount
            if (override > 0) {
                console.log("Social Security Override Amount should be greater than 0!");
                await this.ssnOverrideAmt.click();
                await this.ssnOverrideAmt.setValue(override);
            } else {
                console.log("Invalid Social Security Override Amount : "+override);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async defaultCalcValues () {
        try {
            await browser.pause(200);
            // Click on Default Value
            await this.getDefaultValue.click();
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterAdditionalIncome (override) {
        try {
            // Check Additional Income 
            if (override > 0) {
                console.log("Additional Income should be greater than 0!");
                await browser.pause(4000);
                await this.additionAmt.click();
                await this.additionAmt.setValue(override);
            } else {
                console.log("Invalid Additional Income : "+override);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterYearsofRetirementNeedsLast (year) {
        try {
            await browser.pause(200);
            // Check Years do you plan to depend on retirement income
            if (year > 0) {
                console.log("Years do you plan to depend on retirement income should be greater than 0!");
                await this.yearsofRetirementNeedsLast.click();
                await this.yearsofRetirementNeedsLast.setValue(year);
            } else {
                console.log("Invalid Years do you plan to depend on retirement income : "+year);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterPostRetireIncomeIncWithInflation (status) {
        try {
            await browser.pause(200);
            status = status.toLowerCase();
            // Check Post-retirement income
            if (status.includes("y")) {
                 console.log("Post-retirement income increase with inflation!");
                 await this.postRetireYes.click();
             }
             else if (status.includes("n")) {
                console.log("Post-retirement income doesn't increase with inflation!");
                await this.postRetireNo.click();
            }else {
                 throw("Invalid input for post-retirement income increase with inflation : "+ ssn);
             } 
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterExpectedInflationRate (year) {
        try {
            await browser.pause(200);
            // Check Inflation Rate
            if (year > 0) {
                console.log("Inflation Rate should be greater than 0!");
                await this.expectedInflationRate.click();
                await this.expectedInflationRate.setValue(year);
            } else {
                console.log("Invalid Inflation Rate : "+year);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterPercenFinalAnnualIncomeDesired (year) {
        try {
            await browser.pause(200);
            // Check Final annual income do you want available in each year of your retirement
            if (year > 0) {
                console.log("Final annual income do you want available in each year of your retirement should be greater than 0!");
                await this.percenFinalAnnualIncomeDesired.click();
                await this.percenFinalAnnualIncomeDesired.setValue(year);
            } else {
                console.log("Invalid Final annual income do you want available in each year of your retirement : "+year);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterPreRetireInvestmentReturn (rate) {
        try {
            await browser.pause(200);
            // Check Pre-retirement investment return
            if (rate > 0) {
                console.log("Pre-retirement investment return should be greater than 0!");
                await this.preRetireInvestmentReturn.click();
                await this.preRetireInvestmentReturn.setValue(rate);
            } else {
                console.log("Invalid Pre-retirement investment return : "+rate);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async enterPostRetirInveReturn (rate) {
        try {
            await browser.pause(200);
            // Check Post-retirement investment return
            if (rate > 0) {
                console.log("Post-retirement investment return should be greater than 0!");
                await this.postRetirInveReturn.click();
                await this.postRetirInveReturn.setValue(rate);
            } else {
                console.log("Post-retirement investment return : "+rate);
            }
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async saveButtonClick () {
        try {
                await browser.pause(200);
                await browser.takeScreenshot();
                console.log("Save Button");
                // Click on Save button
                await this.saveChangesButton.click();
            
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async submitButtonClick () {
        try {
                await browser.pause(200);
                console.log("Submit Button");
                // Click on Submit button
                await this.submitButton.click();
                await browser.takeScreenshot();
            
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    async verifyReport () {
        try {
            await browser.pause(5000);
            // Verify Results
            var text = await this.resultText.getText();
            text = text.toLowerCase();
            if (text.includes("result")) {
                // Verify the content of report
               text = await this.reportContent.getText();
               var textLower = text.toLowerCase();
               if (textLower.includes("congrat")) {
                    console.log(text);
               } else {
                    console.log(text);
               }
            }    
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }

    async socialSecurityAsNo () {
        try {
            await browser.pause(200);
            console.log("Social Security benifits is selected as No!");
            await this.ssnInputNo.click();
            await browser.pause(2000);
            var ssnOverrideStatus = await this.socialSecurityAsText.isDisplayed();
            var maritalStatus = await this.maritalStatusAsText.isDisplayed();
            console.log(ssnOverrideStatus +" : "+maritalStatus);
            if (!ssnOverrideStatus && !maritalStatus) {
                console.log("Social Security Benifits is selected as No");
            } else {
                throw("Social Security Benifits is selected as Yes")
            }
               
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }

    async socialSecurityAsYes () {
        try {
            await browser.pause(200);
            console.log("Social Security benifits is selected as Yes!");
            await this.ssnInputYes.click();
            await browser.pause(2000);
            var ssnOverrideStatus = await this.socialSecurityAsText.isDisplayed();
            var maritalStatus = await this.maritalStatusAsText.isDisplayed();

            if (ssnOverrideStatus && maritalStatus) {
                console.log("Social Security Benifits is selected as Yes");
            } else {
                throw("Social Security Benifits is selected as No")
            }
               
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }

    async verifyDefaultValues (additionAmt, yearsofRetirementNeedsLast) {
        try {
            var text;
            await browser.pause(1000);
            await this.defaultCalcValues();
            // Get other income will you have during retirement
            text = await this.additionAmt.getValue();
            text = text.replaceAll('$', '');
            expect(parseFloat(text)).toEqual(parseFloat(additionAmt));
            console.log( "Additonal Amount Income is Saved!");
               
        } catch (error) {
            console.log(error);
            throw new Error(error);
        }
    }
    
}

module.exports = new RetireCalc();
